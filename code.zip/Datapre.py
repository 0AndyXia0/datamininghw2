# coding = utf-8
import pandas
DataFile = open("F:/Users/andy/Documents/HW/Building_Permits.csv",encoding='gb18030',errors='ignore')
DataTable = pandas.read_csv(DataFile);
NominalAttribute = ['Permit Number', 'Permit Type', 'Permit Type Definition', 'Permit Creation Date', 'Block', 'Lot',
                    'Street Number', 'Street Number Suffix', 'Street Name', 'Street Name Suffix', 'Unit suffix',
                    'Description', 'Current Status', 'Current Status Date', 'Filed Date', 'Issued Date',
                    'Completed Date', 'First Construction Document Date', 'Structural Notification', 'Fire Only Permit',
                    'Permit Expiration Date', 'Existing Use', 'Proposed Use', 'Plansets', 'TIDF Compliance',
                    'Existing Construction Type', 'Existing Construction Type Description',
                    'Proposed Construction Type', 'Proposed Construction Type Description', 'Site Permit',
                    'Neighborhoods - Analysis Boundaries', 'Zipcode', 'Location'];
NominalAttributeAbstract = dict();
# 二值属性：
BinaryAttribute = ['Structural Notification', 'Voluntary Soft-Story Retrofit', 'Fire Only Permit', 'Site Permit'];
# 数值属性
NumericAttribute = ['Unit', 'Number of Existing Stories', 'Number of Proposed Stories', 'Estimated Cost',
                    'Revised Cost', 'Existing Units', 'Proposed Units', 'Supervisor District'];
NumericAttributeAbstract = dict();
#删除部分属性
DeletAttribute = ['Completed Date', 'Record ID', 'TIDF Compliance','Permit Number', 'Permit Creation Date', 'Block', 'Lot',
                    'Street Number', 'Street Number Suffix', 'Street Name','Current Status Date',
                    'Filed Date', 'Issued Date','Completed Date', 'First Construction Document Date', 
                    'Permit Expiration Date', 'Existing Use', 'Proposed Use', 'Plansets', 'TIDF Compliance',
                    'Existing Construction Type Description',
                    'Proposed Construction Type', 'Proposed Construction Type Description','Unit Suffix','Existing Construction Type','Description',
                    'Neighborhoods - Analysis Boundaries', 'Zipcode', 'Location','Unit', 'Number of Existing Stories', 'Number of Proposed Stories', 'Estimated Cost',
                    'Revised Cost', 'Existing Units', 'Proposed Units'];
DataTable = DataTable.drop(columns=DeletAttribute);
# 二值属性，空值设置为N
DataTable[BinaryAttribute] = DataTable[BinaryAttribute].fillna(value='N');
DataTable[['Supervisor District']] = DataTable[['Supervisor District']].fillna(value=0);
#输出预处理之后的结果到文件
DataTable.to_csv("test.csv",index=False,sep=',')
